package com.example.demo;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.repository.TableRepository;
import com.example.demo.repository.UserRepository;

@RestController
public class helloapi {
	
	@Autowired
	UserRepository userRepository;
	
	@Autowired
	TableRepository tableRepository;

	@CrossOrigin(origins = "*")
	@PostMapping("/join")
	public String join(@RequestBody user user) {
		user newUser = userRepository.save(user);
	
		return "완료";
	}
	
	@CrossOrigin(origins = "*")
	@PostMapping("/tableuse")
	public String TableWrite(@RequestBody board board) {
		board newBoard = tableRepository.save(board);
		
		return "작성완료";
	}
	
	@CrossOrigin(origins = "*")
	@GetMapping("/login")
	public user login(@RequestParam String num,@RequestParam String pwd) {
		user user = userRepository.findByNumAndPwd(num,pwd);
		return user;
	}
	
	@CrossOrigin(origins = "*")
	@GetMapping("/boardAllResult")
	public List<board> boardAllResult() {
		return tableRepository.findAll();
	}
	
	@CrossOrigin(origins = "*")
	@GetMapping("/boardDelete")
	public String boardDelete(@RequestParam Long id) {
		//Optional<board> SeletBoard = tableRepository.findById(id);
		tableRepository.deleteById(id);
		return "삭제 완료!";
	}
	
	@CrossOrigin(origins = "*")
	@PostMapping("/boardEdit")
	public String boardEdit(@RequestBody board board) {
		board newBoard = tableRepository.findByUsernameAndUsertime(board.getUsername(),board.getUsertime());
		tableRepository.deleteById(newBoard.getId());
		
		tableRepository.save(board);
		
		return "삭제 완료!";
	}


	
}



